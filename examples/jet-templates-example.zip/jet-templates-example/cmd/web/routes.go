package main

import (
	"jet-templates-example/internal/handlers"
	"net/http"

	"github.com/bmizerany/pat"
)

// routes handles application routes
func routes() http.Handler {
	mux := pat.New()

	mux.Get("/", http.HandlerFunc(handlers.Home))

	return mux
}
